package com.example.hamzaapp; // Replace with your actual package name
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import com.example.hamzaapp.DatabaseHelper;

public class LoginActivity extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button loginButton;
    private Button createAccountButton;

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize UI components
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.loginButton);
        createAccountButton = findViewById(R.id.createAccountButton);

        // Initialize the database helper
        databaseHelper = new DatabaseHelper(this);
    }

    public void onLoginButtonClick(View view) {
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        // Check user credentials
        if (databaseHelper.checkUser(username, password)) {
            // User exists, navigate to the main activity
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        } else {
            // Show an error message or handle unsuccessful login
            // ...
        }
    }

    public void onCreateAccountClick(View view) {
        // Navigate to the registration activity
        Intent intent = new Intent(this, RegistrationActivity.class);
        startActivity(intent);
    }
}
